#!/usr/bin/env python3
"""repo_report.py - list a GitHub user's repositories and flag the stale ones.

Usage:
    python repo_report.py De-senator26
    python repo_report.py De-senator26 --stale-days 90 --csv report.csv

Set GITHUB_TOKEN to raise the API rate limit (60 requests/hour without a token,
5,000 with one). The token never needs more than read access to public data.
"""
import argparse
import csv
import os
import sys
from datetime import datetime, timezone

import requests

API = "https://api.github.com"


def fetch_repos(user, token=None):
    """Return every public repo for `user`, following pagination."""
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    repos, page = [], 1
    while True:
        resp = requests.get(
            f"{API}/users/{user}/repos",
            headers=headers,
            params={"per_page": 100, "page": page, "type": "owner"},
            timeout=15,
        )
        if resp.status_code == 404:
            sys.exit(f"User '{user}' not found.")
        if resp.status_code == 403:
            sys.exit("Rate limit hit. Set GITHUB_TOKEN and try again.")
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            return repos
        repos.extend(batch)
        page += 1


def days_since(iso_timestamp, now=None):
    """Whole days between an ISO 8601 timestamp (e.g. 2026-01-05T10:00:00Z) and now."""
    now = now or datetime.now(timezone.utc)
    pushed = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
    return (now - pushed).days


def summarize(repos, stale_days, now=None):
    """Turn raw API repos into report rows, most recently pushed first."""
    rows = []
    for r in repos:
        age = days_since(r["pushed_at"], now) if r.get("pushed_at") else None
        rows.append({
            "name": r["name"],
            "language": r.get("language") or "-",
            "stars": r["stargazers_count"],
            "open_issues": r["open_issues_count"],
            "days_since_push": age if age is not None else "never",
            "stale": "yes" if age is None or age > stale_days else "no",
        })
    rows.sort(key=lambda x: (x["days_since_push"] == "never", x["days_since_push"]
                             if x["days_since_push"] != "never" else 0))
    return rows


def print_table(rows):
    cols = ["name", "language", "stars", "open_issues", "days_since_push", "stale"]
    widths = {c: max(len(c), *(len(str(r[c])) for r in rows)) for c in cols} if rows else {}
    print("  ".join(c.ljust(widths[c]) for c in cols) if rows else "No repositories found.")
    for r in rows:
        print("  ".join(str(r[c]).ljust(widths[c]) for c in cols))


def write_csv(rows, path):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nSaved {len(rows)} rows to {path}")


def main():
    p = argparse.ArgumentParser(description="Report on a GitHub user's repositories.")
    p.add_argument("user", help="GitHub username")
    p.add_argument("--stale-days", type=int, default=180,
                   help="flag repos with no push in this many days (default 180)")
    p.add_argument("--csv", help="also write the report to this CSV file")
    args = p.parse_args()

    rows = summarize(fetch_repos(args.user, os.environ.get("GITHUB_TOKEN")), args.stale_days)
    print_table(rows)
    stale = sum(1 for r in rows if r["stale"] == "yes")
    print(f"\n{len(rows)} repos, {stale} stale (no push in {args.stale_days}+ days).")
    if args.csv and rows:
        write_csv(rows, args.csv)


if __name__ == "__main__":
    main()
