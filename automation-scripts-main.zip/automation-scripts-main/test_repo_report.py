from datetime import datetime, timezone

from repo_report import days_since, summarize

NOW = datetime(2026, 10, 19, tzinfo=timezone.utc)


def test_days_since():
    assert days_since("2026-10-09T00:00:00Z", NOW) == 10


def test_summarize_flags_stale_and_sorts():
    repos = [
        {"name": "old", "language": "Python", "stargazers_count": 1,
         "open_issues_count": 0, "pushed_at": "2025-01-01T00:00:00Z"},
        {"name": "new", "language": None, "stargazers_count": 3,
         "open_issues_count": 2, "pushed_at": "2026-10-10T00:00:00Z"},
        {"name": "empty", "language": None, "stargazers_count": 0,
         "open_issues_count": 0, "pushed_at": None},
    ]
    rows = summarize(repos, 180, NOW)
    assert [r["name"] for r in rows] == ["new", "old", "empty"]
    assert [r["stale"] for r in rows] == ["no", "yes", "yes"]
    assert rows[0]["language"] == "-"
