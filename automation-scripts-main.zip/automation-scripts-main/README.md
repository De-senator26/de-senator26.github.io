# automation-scripts

Small, practical scripts that remove repetitive work for developer teams. Each script does one job, has no hidden setup, and is easy to read and change.

Written by Tombir Anslem Swengka ([ANSTECH](https://de-senator26.github.io)).

## repo_report.py

Lists every public repository for a GitHub user and flags the ones with no recent activity, so you can see at a glance what needs attention or archiving.

### Setup

```bash
pip install -r requirements.txt
```

### Run

```bash
python repo_report.py De-senator26
python repo_report.py De-senator26 --stale-days 90 --csv report.csv
```

Example output (columns: repo, language, stars, open issues, days since last push, stale):

```
name             language  stars  open_issues  days_since_push  stale
automation-site  Python    2      1            4                no
old-experiment   Java      0      0            412              yes
```

### Optional: GitHub token

Without a token GitHub allows 60 API requests per hour, which is plenty for one user. For more, create a token with read-only access and set it as an environment variable. Never commit a token to a repository.

```bash
export GITHUB_TOKEN=your_token_here      # macOS/Linux
set GITHUB_TOKEN=your_token_here         # Windows (cmd)
```

### Tests

```bash
python -c "import test_repo_report as t; t.test_days_since(); t.test_summarize_flags_stale_and_sorts(); print('ok')"
```

(or `pip install pytest` and run `pytest`).
